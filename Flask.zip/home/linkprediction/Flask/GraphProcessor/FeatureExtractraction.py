import networkx as nx
from operator import itemgetter
import operator
import random


def common_neighbors(G, ebunch):
    ret = []

    for edge in ebunch:
        u, v = edge[0], edge[1]
        neighbors = sum(1 for _ in nx.common_neighbors(G, u, v))
        ret.append((u, v, neighbors))

    return ret


def ProcessNetwork(G, u):
    ebunch = []
    for v in G.nodes():
        if v not in G.neighbors(u) and v != u:
            ebunch.append((u, v))

    rankList = []
    # Common Neighbors
    neighbor_list = common_neighbors(G,ebunch)
    neighbors = sorted(neighbor_list, key=itemgetter(2), reverse=True)#[:10]
    rankList.append(neighbors)

    """# Adamic Adar
    neighbor_list = nx.adamic_adar_index(G, ebunch)
    neighbors = sorted(neighbor_list, key=itemgetter(2), reverse=True)#[:10]
    rankList.append(neighbors)

    # Jaccard's Coefficient
    neighbor_list = nx.jaccard_coefficient(G, ebunch)
    neighbors = sorted(neighbor_list, key=itemgetter(2), reverse=True)#[:10]
    rankList.append(neighbors)"""

    for item in G.node[u].keys():
        property_list = sim_index(G, ebunch, community=item)
        property = sorted(property_list, key=itemgetter(2), reverse=True)#[:10]
        rankList.append(property)

    """year_list = sim_index(G, ebunch, community='year')
    department_list = sim_index(G, ebunch, community='department')
    native_place_list = sim_index(G, ebunch, community='native_place')
    gender_list = sim_index(G, ebunch, community='gender')

    year = sorted(year_list, key=itemgetter(2), reverse=True)#[:10]
    department = sorted(department_list, key=itemgetter(2), reverse=True)#[:10]
    native_place = sorted(native_place_list, key=itemgetter(2), reverse=True)#[:10]
    gender = sorted(gender_list, key=itemgetter(2), reverse=True)#[:10]


    rankList.append(year)
    rankList.append(department)
    rankList.append(native_place)
    rankList.append(gender)"""
    weights = [1 for item in range(len(rankList)+1)]

    return rank(rankList,weights)


def rank(list1, list2):  # O(n^2)
    final_list = []
    rows = len(list1)
    flattened = [val[1] for sublist in list1 for val in sublist]
    flattened = set(flattened)
    d = dict.fromkeys(flattened, 0)
    for row in xrange(rows):
        p = list2[row]
        cols = len(list1[row])
        d[list1[row][0][1]] += p
        for col in xrange(1, cols):
            x = col - 1
            if list1[row][col][2] == list1[row][x][2]:
                d[list1[row][col][1]] += p
            else:
                p *= 0.8
                d[list1[row][col][1]] += p
    sortedx = sorted(d.items(), key=operator.itemgetter(1), reverse=True)
    sortedx = randomize(sortedx)
    for i in sortedx:
        final_list.append(i[0])
    return final_list


def sim_index(G, ebunch=None, community='name'):
    if ebunch is None:
        ebunch = nx.non_edges(G)

    def predict(u, v):
        if community in G.node[u].keys() and community in G.node[v].keys():
            Cu = _community(G, u, community)
            Cv = _community(G, v, community)
            if Cu == Cv:
                if 'name' in G.node[v] and G.node[v]['name'] == 'Default User':
                    return 0.5
                else:
                    return 1
            else:
                return 0
        else:
            return 0

    return ((u, v, predict(u, v)) for u, v in ebunch)


def _community(G, u, community):
    """Get the community of the given node."""
    node_u = G.node[u]
    try:
        return node_u[community]
    except KeyError:
        print u,community
        raise nx.NetworkXAlgorithmError('No community information')


def randomize(data_list):       # O(n)
    final_list=[]
    data_list1=[]
    data_list1.append(data_list[0])
    for iterator in range(1,len(data_list)):
        if data_list[iterator][1] == data_list[iterator-1][1]:
            data_list1.append(data_list[iterator])
            random.shuffle(data_list1)
        else:
            list_var=data_list[iterator]
            final_list.extend(data_list1)
            del data_list1[:]
            data_list1.append(list_var)
    random.shuffle(data_list1)
    final_list.extend(data_list1)
    return final_list