from flask import Flask, render_template, session, request, redirect, g, url_for, flash
import os
import networkx as nx
from Read.ReadDataSet import *
from GraphProcessor.FeatureExtractraction import *
from Util.accuracy import *
from Util.load import *
app=Flask(__name__)
app.secret_key=os.urandom(24)
#rd = ReadDataSet("Data/Dataset")
#rd.readCSV()
G=load()
dict=[]
@app.route('/',methods=['GET','POST'])
def index(error=None):
    G=load()
    if request.method=='POST':
        session.pop('user',None)
        if request.form['password']==request.form['username']:
            session['user']=request.form['username']
            roll_no=request.form['username']
            if G.has_node(roll_no):
               # print request.form['username']
                flash('You are logged in')
                return redirect(url_for('profile'))
            else:
                error="No User Found with this Username!!"
        else:
            error = 'Invalid username or password. Please try again!'
    return render_template('index.html',error=error)

@app.route('/profile')
def profile():
    if request.method=='GET':
        pass
    if g.user:
        roll_no=session['user']
        dict=G.node[roll_no].copy()
        dict['roll_no']=roll_no
        return render_template("profile.html",name=dict)
    return redirect(url_for('index'))

@app.before_request
def before_request():
    g.user=None
    if 'user' in session:
        g.user=session['user']


@app.route('/signup',methods=['GET','POST'])
def signup():
    if request.method=='POST':
        #call insrt method of ashutosh
        line="Defaulttimestamp,"+request.form['roll_no']+","+request.form['name']+","+request.form['gender']+","+request.form['place']+","+request.form['email']+",,,,,"
        readPersonalDetails(G,line)
        flush(G)
        return redirect(url_for('index'))


@app.route('/getsession')
def getsession():
    if 'user' in session:
        return session['user']
    return 'not logged in!'

@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect(url_for('index'))


@app.route('/suggest')
def suggest():
    G=load()
    roll_no=(str)(session['user'])
    friend_list_rollno=ProcessNetwork(G,roll_no)[:10]
    friend_list_name=[]
    for rollno in friend_list_rollno:
        ls = G.node[rollno].copy()
        ls['roll_no'] = rollno
        friend_list_name.append(ls)
    #print friend_list_name
    return render_template("Suggested-friends.html",name=friend_list_name,user=session['user'])

@app.route('/friends')
def friends():
    G=load()
    roll_no = (str)(session['user'])
    friend_list_rollno = nx.neighbors(G,roll_no)
    friend_list_name = []
    for rollno in friend_list_rollno:
        ls=G.node[rollno].copy()
        ls['roll_no']=rollno
        friend_list_name.append(ls)

    # print friend_list_name
    return render_template("friends.html", name=friend_list_name, user=session['user'])

@app.route('/addfriend/<rollno>')
def addfriend(rollno):
    G.add_edge((str)(session['user']),rollno)
    flush(G)
    return redirect(url_for('suggest'))